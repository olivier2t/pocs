# stack-nginx-aks

This stack deploys a scalable NGINX on an Azure Kubernetes Service (AKS) cluster via Terraform
