# stack-drupal-eks

Service catalog deploying a Drupal on AWS EKS cluster, connecting to an external MySQL database.

